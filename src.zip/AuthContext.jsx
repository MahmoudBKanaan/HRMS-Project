


import { createContext ,  useState, useEffect } from "react";


export const AuthContext = createContext(false);


export const AuthProvider = ({ children }) => {

    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [addUser, setAddUser] = useState(false)
    const [departments, setDepartments] = useState({})
    const [accounts, setAccounts] = useState({})
    

    useEffect(() => {
    const accountsvar = JSON.parse(localStorage.getItem("accounts"));
    if(accountsvar) {
        setAccounts({ ...accountsvar })
    }
    const dept = JSON.parse(localStorage.getItem("departments"));
    if(dept) {
        setDepartments({ ...dept })
    }
    },[])


    useEffect(() => {
    localStorage.setItem("accounts", JSON.stringify(accounts))
    },[accounts])
    useEffect(() => {
    localStorage.setItem("departments", JSON.stringify(departments))
    },[departments])



    const getStoredToken = () => {
        return localStorage.getItem("token") || sessionStorage.getItem("token");}
        
        const getStoredIsAdmin = () => {
            return localStorage.getItem("isAdmin") || sessionStorage.getItem("isAdmin");
        }
        
        useEffect ( () => {
            const token = getStoredToken();
            const storedIsAdmin = getStoredIsAdmin();
            if (token) {
                setIsAuthenticated(true);
                if ( storedIsAdmin === "true"){
                    setIsAdmin(true)
                }
            } else if (!token) {
                setIsAuthenticated(false);
                if (storedIsAdmin === "false"){
                    setIsAdmin(false)
                }
            }
            setIsLoading(false);
        }, [])
        




    return (
        <AuthContext.Provider value={{
            isAuthenticated, setIsAuthenticated, 
            isLoading, setIsLoading, 
            isAdmin, setIsAdmin, 
            addUser , setAddUser,
            accounts, setAccounts,
            departments, setDepartments
        }} >
            {children}


        </AuthContext.Provider>
    )
}