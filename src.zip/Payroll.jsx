import {Sidebar} from "/src/components/Sidebar.jsx"
import { Navbar } from '/src/components/Navbar';
import { FaUsers, FaCheckCircle, FaMoneyBillWave,FaRegClock  } from 'react-icons/fa';
import { StatsCard } from "./Attendance";
import { useContext, useState } from "react";
import "/src/Attendance.css"
import { AuthContext } from '/src/AuthContext';



const Payroll = () => {
    
    const [madePayments, setMadePayments]   = useState();
    const [pendingPayments, setPendingPayments] = useState();
    const [employeeNumber, setEmployeeNumber]     = useState();
    const [totalPayroll, setTotalPayroll]           = useState();

    const { departments} = useContext(AuthContext);
        
/*     useEffect(() => {
        if(!departments) return
        
        const countPresent = Object.values(departments).flat().filter(user => user.checkedin !== null && user.checkedout === null ).length;
        setPresentEmployees(countPresent)
        
        const countAbsent = Object.values(departments).flat().filter(user => user.checkedin === null || user.checkedout !== null ).length;
        setAbsentEmployees(countAbsent)
        
        let countTotalPayroll = 0;
        let sumAttendance = 0;
        Object.entries(departments).forEach(([dept, users]) => {
        users.forEach((user) => {
                countTotalPayroll = countTotalPayroll+
                Number(user.payroll.baseSalary)+
                Number(user.payroll.housingBenefits)+
                Number(user.payroll.transportationBenefits)+
                Number(user.payroll.foodBenefits)+
                Number(user.payroll.commissions)-
                Number(user.payroll.deductions);
                sumAttendance = sumAttendance+parseFloat( user.attendance.replace("%", ""))
            }
            )
        }
        )
        let averageAttendance = Number((sumAttendance/(countPresent+countAbsent)).toFixed(2));
        setAverageAttendance(averageAttendance)
        countTotalPayroll = countTotalPayroll.toLocaleString();
        setTotalPayroll(countTotalPayroll)
    },[departments]) */
    
    const getMadePayments = () => {
        return /* `${madePayments}%` */ "44"
    }
    const getPendingPayments = () => {
        return /* `${pendingPayments}` */ "44"
    }
    const getEmployeeNumber = () => {
        return /* `${employeeNumber}` */ "44"
    }
    const getTotalPayroll = () => {
        return /* `$${totalPayroll}` */ "44"
    }
    


    return (
        <div className='AttendanceContainer'>
        <Sidebar />
        <div className="mainContent">
        <Navbar  navTitle="Payroll" navText="View Payroll Details" />
            
        <div className="cardsContainer">
        < StatsCard icon={<FaCheckCircle />}    label="Made Payments"   value= {getMadePayments()}  />
        < StatsCard icon={<FaRegClock />}       label="Pending"         value= {getPendingPayments()}  />
        < StatsCard icon={<FaUsers />}          label="Employees"       value= {getEmployeeNumber()}  />
        < StatsCard icon={<FaMoneyBillWave />}  label="Total Payroll"   value= {getTotalPayroll()}  />
        </div>


















        </div>
        </div>
    );
};

export default Payroll;